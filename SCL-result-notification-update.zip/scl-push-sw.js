/* SCL Result Upload Push Notifications Service Worker */
self.addEventListener("push", (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch (_) {
    data = { title: "SCL Result Upload Reminder", body: event.data ? event.data.text() : "A result-upload reminder is ready." };
  }

  const title = data.title || "SCL Result Upload Reminder";
  const options = {
    body: data.body || "A result-upload reminder is ready.",
    icon: data.icon || "./favicon.ico",
    badge: data.badge || "./favicon.ico",
    tag: data.tag || "scl-result-reminder",
    renotify: true,
    requireInteraction: true,
    data: { url: data.url || "./" }
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const target = new URL(
    (event.notification.data && event.notification.data.url) || "./",
    self.location.origin
  ).href;

  event.waitUntil(
    clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ("focus" in client) {
          client.navigate(target);
          return client.focus();
        }
      }
      if (clients.openWindow) return clients.openWindow(target);
    })
  );
});
